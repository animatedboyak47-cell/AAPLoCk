package com.example.applock
import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class LockService : AccessibilityService() {
    companion object { @Volatile var unlocked: String? = null }
    private val ignore = setOf("com.android.systemui", "com.samsung.android.honeyboard", "com.google.android.inputmethod.latin")
    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg in ignore) return
        if (pkg != unlocked) unlocked = null
        if (pkg in Store.apps(this) && unlocked == null && Store.type(this) != null) {
            startActivity(Intent(this, LockActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                .putExtra("pkg", pkg))
        }
    }
    override fun onInterrupt() {}
}
