package com.example.applock
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat

class LockActivity : AppCompatActivity() {
    private var pkg = ""
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        pkg = intent.getStringExtra("pkg") ?: ""
        val type = Store.type(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(48, 48, 48, 48) }
        root.addView(TextView(this).apply { text = "Enter credential to unlock"; textSize = 20f; gravity = Gravity.CENTER })
        if (type == "PATTERN") {
            root.addView(PatternView(this) { if (Store.check(this, it)) ok() else toast("Wrong pattern") })
        } else {
            val et = EditText(this).apply {
                inputType = if (type == "PASS") InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                            else InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
                imeOptions = EditorInfo.IME_ACTION_DONE; gravity = Gravity.CENTER
            }
            val go = { if (Store.check(this, et.text.toString())) ok() else { et.text.clear(); toast("Wrong") } }
            et.setOnEditorActionListener { _, _, _ -> go(); true }
            root.addView(et); root.addView(Button(this).apply { text = "Unlock"; setOnClickListener { go() } })
        }
        if (Store.bio(this)) root.addView(Button(this).apply { text = "Use fingerprint / face"; setOnClickListener { bio() } })
        setContentView(root)
        if (Store.bio(this)) bio()
    }
    private fun bio() {
        val auth = BiometricManager.Authenticators.BIOMETRIC_WEAK // WEAK allows Samsung face unlock too
        if (BiometricManager.from(this).canAuthenticate(auth) != BiometricManager.BIOMETRIC_SUCCESS) return
        val p = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) = ok()
        })
        p.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("Unlock app")
            .setAllowedAuthenticators(auth).setNegativeButtonText("Use credential").build())
    }
    private fun ok() { LockService.unlocked = pkg; finish() }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    @Deprecated("") override fun onBackPressed() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); finish()
    }
}
