package com.example.applock
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val types = listOf("PIN4" to "PIN (4 digits)", "PIN6" to "PIN (6 digits)", "PASS" to "Password (letters + numbers, min 4)", "PATTERN" to "Pattern")
    private var pattern = ""
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        val sv = ScrollView(this).apply { addView(col) }
        fun tv(s: String) = TextView(this).apply { text = s; textSize = 16f; setPadding(0, 24, 0, 8) }
        col.addView(tv("1. Choose lock type"))
        val sp = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, types.map { it.second }) }
        val et = EditText(this).apply { hint = "Enter credential" }
        val pv = PatternView(this) { pattern = it; toast("Pattern captured") }.apply { visibility = View.GONE }
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, i: Int, id: Long) {
                val t = types[i].first
                et.visibility = if (t == "PATTERN") View.GONE else View.VISIBLE
                pv.visibility = if (t == "PATTERN") View.VISIBLE else View.GONE
                et.inputType = if (t == "PASS") 129 else 18 // text password / number password
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        col.addView(sp); col.addView(et); col.addView(pv)
        col.addView(Button(this).apply { text = "Save credential"; setOnClickListener {
            val t = types[sp.selectedItemPosition].first; val s = if (t == "PATTERN") pattern else et.text.toString()
            val valid = when (t) { "PIN4" -> s.matches(Regex("\\d{4}")); "PIN6" -> s.matches(Regex("\\d{6}")); "PASS" -> s.length >= 4; else -> s.length >= 4 }
            if (!valid) toast("Invalid for this type") else { Store.save(this@MainActivity, t, s); et.text.clear(); toast("Saved") }
        } })
        col.addView(tv("2. Biometrics"))
        col.addView(Switch(this).apply { text = "Fingerprint / face unlock"; isChecked = Store.bio(this@MainActivity)
            setOnCheckedChangeListener { _, c -> Store.setBio(this@MainActivity, c) } })
        col.addView(tv("3. Enable service (find App Lock > turn on)"))
        col.addView(Button(this).apply { text = "Open Accessibility settings"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } })
        col.addView(tv("4. Pick apps to lock"))
        val sel = Store.apps(this).toMutableSet()
        val pm = packageManager
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }.distinct()
            .filter { it.first != packageName }.sortedBy { it.second.lowercase() }.forEach { (pkg, name) ->
                col.addView(CheckBox(this).apply { text = name; isChecked = pkg in sel
                    setOnCheckedChangeListener { _, c -> if (c) sel.add(pkg) else sel.remove(pkg); Store.setApps(this@MainActivity, sel.toSet()) } })
            }
        setContentView(sv)
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
