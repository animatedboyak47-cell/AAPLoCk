package com.example.applock
import android.content.Context
import java.security.MessageDigest
import java.util.UUID

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("lock", 0)
    private fun hash(s: String, salt: String) =
        MessageDigest.getInstance("SHA-256").digest((salt + s).toByteArray()).joinToString("") { "%02x".format(it) }
    // type: PIN4, PIN6, PASS, PATTERN
    fun save(c: Context, type: String, secret: String) {
        val salt = UUID.randomUUID().toString()
        sp(c).edit().putString("type", type).putString("salt", salt).putString("h", hash(secret, salt)).apply()
    }
    fun type(c: Context) = sp(c).getString("type", null)
    fun check(c: Context, s: String): Boolean {
        val salt = sp(c).getString("salt", null) ?: return false
        return hash(s, salt) == sp(c).getString("h", "")
    }
    fun apps(c: Context): Set<String> = sp(c).getStringSet("apps", emptySet())!!
    fun setApps(c: Context, s: Set<String>) = sp(c).edit().putStringSet("apps", s).apply()
    fun bio(c: Context) = sp(c).getBoolean("bio", true)
    fun setBio(c: Context, b: Boolean) = sp(c).edit().putBoolean("bio", b).apply()
}
