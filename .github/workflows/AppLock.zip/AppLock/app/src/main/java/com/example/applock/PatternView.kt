package com.example.applock
import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View

class PatternView(c: Context, val onDone: (String) -> Unit) : View(c) {
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.GRAY }
    private val on = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(33, 150, 243) }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(33, 150, 243); strokeWidth = 12f }
    private val sel = mutableListOf<Int>()
    private var cx = 0f; private var cy = 0f
    private fun pt(i: Int) = PointF(width * (i % 3 * 2 + 1) / 6f, height * (i / 3 * 2 + 1) / 6f)
    override fun onMeasure(w: Int, h: Int) { val s = MeasureSpec.getSize(w); setMeasuredDimension(s, s) }
    override fun onDraw(c: Canvas) {
        for (i in 1 until sel.size) { val a = pt(sel[i - 1]); val b = pt(sel[i]); c.drawLine(a.x, a.y, b.x, b.y, line) }
        if (sel.isNotEmpty()) { val a = pt(sel.last()); c.drawLine(a.x, a.y, cx, cy, line) }
        for (i in 0..8) { val p = pt(i); c.drawCircle(p.x, p.y, 24f, if (i in sel) on else dot) }
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        cx = e.x; cy = e.y
        if (e.action == MotionEvent.ACTION_DOWN) sel.clear()
        for (i in 0..8) { val p = pt(i); if (i !in sel && Math.hypot((p.x - cx).toDouble(), (p.y - cy).toDouble()) < 60) sel.add(i) }
        if (e.action == MotionEvent.ACTION_UP) {
            val r = sel.joinToString(""); sel.clear(); invalidate()
            if (r.length >= 4) onDone(r)
        } else invalidate()
        return true
    }
}
